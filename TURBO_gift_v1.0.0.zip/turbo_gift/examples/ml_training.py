"""
TURBO_gift ML Training Example
==============================

This example demonstrates how to use TURBO_gift to optimize
machine learning training workloads.

Note: This example uses pure numpy to simulate ML operations.
For actual PyTorch/TensorFlow integration, use TurboTensor/TurboTFTensor.

Run: python examples/ml_training.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import time

from core.engine import (
    TurboEngine, TurboConfig, OptimizationLevel, PrecisionMode
)


def simulate_forward_pass(weights, inputs):
    """Simulate a neural network forward pass."""
    return np.tanh(np.dot(inputs, weights))


def simulate_backward_pass(weights, inputs, grad_output):
    """Simulate a neural network backward pass."""
    grad_weights = np.dot(inputs.T, grad_output)
    return grad_weights


def train_without_turbo(batch_size, hidden_size, num_batches):
    """Training loop without TURBO optimization."""
    weights = np.random.randn(batch_size, hidden_size).astype(np.float32)
    
    total_time = 0
    total_memory = 0
    
    for _ in range(num_batches):
        # Allocate fresh arrays each iteration
        inputs = np.random.randn(batch_size, batch_size).astype(np.float32)
        total_memory += inputs.nbytes
        
        start = time.perf_counter()
        
        # Forward
        output = simulate_forward_pass(weights, inputs)
        total_memory += output.nbytes
        
        # Backward
        grad_output = np.random.randn(*output.shape).astype(np.float32)
        total_memory += grad_output.nbytes
        
        grad_weights = simulate_backward_pass(weights, inputs, grad_output)
        total_memory += grad_weights.nbytes
        
        # Update
        weights -= 0.01 * grad_weights
        
        total_time += time.perf_counter() - start
    
    return total_time, total_memory


def train_with_turbo(batch_size, hidden_size, num_batches):
    """Training loop with TURBO optimization."""
    # Configure for ML training
    config = TurboConfig(
        optimization_level=OptimizationLevel.BALANCED,
        precision_mode=PrecisionMode.FP16,  # Use half precision
        enable_pattern_filter=True,
        enable_compaction=True,
        enable_memory_pool=True,
        enable_adaptive_learning=True,
        target_utilization=0.90
    )
    
    engine = TurboEngine(config)
    
    weights = np.random.randn(batch_size, hidden_size).astype(np.float32)
    weights_opt, _ = engine.optimize(weights)
    
    total_time = 0
    total_memory = 0
    
    for i in range(num_batches):
        # Use memory pool for allocations
        inputs = engine.get_buffer((batch_size, batch_size), np.float32)
        inputs[:] = np.random.randn(batch_size, batch_size)
        
        # Optimize inputs
        inputs_opt, meta_in = engine.optimize(inputs)
        total_memory += inputs_opt.nbytes
        
        start = time.perf_counter()
        
        # Forward with optimized data
        output = simulate_forward_pass(weights_opt, inputs_opt)
        output_opt, meta_out = engine.optimize(output)
        total_memory += output_opt.nbytes
        
        # Backward
        grad_buffer = engine.get_buffer(output.shape, np.float32)
        grad_buffer[:] = np.random.randn(*output.shape)
        grad_opt, _ = engine.optimize(grad_buffer)
        total_memory += grad_opt.nbytes
        
        grad_weights = simulate_backward_pass(weights_opt, inputs_opt, grad_opt)
        grad_weights_opt, _ = engine.optimize(grad_weights)
        total_memory += grad_weights_opt.nbytes
        
        # Update (restore to FP32 for update)
        weights_opt = weights_opt - 0.01 * grad_weights_opt
        
        total_time += time.perf_counter() - start
        
        # Return buffers to pool
        engine.release_buffer(inputs)
        engine.release_buffer(grad_buffer)
        
        # Record performance for learning
        engine.record_performance(meta_in, 1.0 / (time.perf_counter() - start + 1e-6))
    
    return total_time, total_memory, engine


def main():
    print("=" * 70)
    print("TURBO_gift ML Training Optimization Example")
    print("=" * 70)
    
    # Training parameters
    batch_size = 256
    hidden_size = 512
    num_batches = 100
    
    print(f"\nConfiguration:")
    print(f"  Batch size: {batch_size}")
    print(f"  Hidden size: {hidden_size}")
    print(f"  Number of batches: {num_batches}")
    
    # Warmup
    print("\nWarming up...")
    train_without_turbo(32, 64, 10)
    train_with_turbo(32, 64, 10)
    
    # Benchmark without TURBO
    print("\nTraining WITHOUT TURBO...")
    time_without, mem_without = train_without_turbo(batch_size, hidden_size, num_batches)
    
    # Benchmark with TURBO
    print("Training WITH TURBO...")
    time_with, mem_with, engine = train_with_turbo(batch_size, hidden_size, num_batches)
    
    # Results
    print("\n" + "=" * 70)
    print("RESULTS")
    print("=" * 70)
    
    print(f"\n{'Metric':<30} {'Without TURBO':>15} {'With TURBO':>15} {'Improvement':>15}")
    print("-" * 75)
    
    time_improvement = (time_without - time_with) / time_without * 100
    print(f"{'Total Time (ms)':<30} {time_without*1000:>15.2f} {time_with*1000:>15.2f} {time_improvement:>14.1f}%")
    
    mem_improvement = (mem_without - mem_with) / mem_without * 100
    print(f"{'Memory Allocated (MB)':<30} {mem_without/1024/1024:>15.2f} {mem_with/1024/1024:>15.2f} {mem_improvement:>14.1f}%")
    
    throughput_without = num_batches / time_without
    throughput_with = num_batches / time_with
    throughput_improvement = (throughput_with - throughput_without) / throughput_without * 100
    print(f"{'Throughput (batches/sec)':<30} {throughput_without:>15.1f} {throughput_with:>15.1f} {throughput_improvement:>14.1f}%")
    
    # Engine statistics
    print("\n" + "=" * 70)
    print("TURBO ENGINE STATISTICS")
    print("=" * 70)
    engine.print_stats()
    
    print("\n" + "=" * 70)
    print("Example complete!")
    print("=" * 70)


if __name__ == '__main__':
    main()
