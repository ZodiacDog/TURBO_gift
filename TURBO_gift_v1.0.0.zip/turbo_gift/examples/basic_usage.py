"""
TURBO_gift Basic Example
========================

This example demonstrates the simplest way to use TURBO_gift
to optimize your data processing.

Run: python examples/basic_usage.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import time

from core.engine import TurboEngine, TurboConfig, turbo_optimize


def main():
    print("=" * 60)
    print("TURBO_gift Basic Usage Example")
    print("=" * 60)
    
    # ==========================================================
    # Example 1: Simplest usage with turbo_optimize()
    # ==========================================================
    print("\n1. Simple One-Liner Optimization")
    print("-" * 40)
    
    # Create some test data
    data = np.random.randn(1000, 1000).astype(np.float32)
    print(f"   Original: {data.shape}, {data.nbytes / 1024 / 1024:.2f} MB")
    
    # Optimize with one line
    optimized, metadata = turbo_optimize(data)
    
    print(f"   Optimized: {optimized.shape}, {optimized.nbytes / 1024 / 1024:.2f} MB")
    print(f"   Savings: {metadata['savings_percent']:.1f}%")
    
    # ==========================================================
    # Example 2: Using the TurboEngine directly
    # ==========================================================
    print("\n2. Using TurboEngine for More Control")
    print("-" * 40)
    
    # Create engine
    engine = TurboEngine()
    
    # Process multiple arrays
    arrays = [np.random.randn(500, 500) for _ in range(5)]
    
    total_original = sum(a.nbytes for a in arrays)
    total_optimized = 0
    
    for i, arr in enumerate(arrays):
        opt, meta = engine.optimize(arr)
        total_optimized += opt.nbytes
        print(f"   Array {i+1}: {meta['savings_percent']:.1f}% reduction")
    
    print(f"   Total: {total_original/1024/1024:.2f} MB → {total_optimized/1024/1024:.2f} MB")
    
    # ==========================================================
    # Example 3: Memory pooling
    # ==========================================================
    print("\n3. Memory Pooling for Hot Paths")
    print("-" * 40)
    
    # Without pooling
    start = time.perf_counter()
    for _ in range(100):
        buf = np.zeros((500, 500))
    without_pool = time.perf_counter() - start
    
    # With pooling
    start = time.perf_counter()
    for _ in range(100):
        buf = engine.get_buffer((500, 500))
        engine.release_buffer(buf)
    with_pool = time.perf_counter() - start
    
    print(f"   Without pool: {without_pool*1000:.2f} ms")
    print(f"   With pool: {with_pool*1000:.2f} ms")
    print(f"   Speedup: {without_pool/with_pool:.1f}x")
    
    # ==========================================================
    # Example 4: View statistics
    # ==========================================================
    print("\n4. Performance Statistics")
    print("-" * 40)
    engine.print_stats()
    
    print("\n" + "=" * 60)
    print("Example complete!")
    print("=" * 60)


if __name__ == '__main__':
    main()
